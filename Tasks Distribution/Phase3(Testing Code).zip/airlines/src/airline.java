import java.util.Scanner;// to print messages to the user.
public class airline {
    private static String username;
    private static String password;
    private static String fname;
    private static String lastname;
    private static String email;
    private static String phone;
    public String fOrigin;
    Scanner in = new Scanner(System.in);
    // collect data from user to create an account/sign in


    private static boolean signIn;
    private boolean signUp;


    //business layer
    public static String getUsername(){return username;}
    public static String getPassword(){return password;}
    public static String getFirstname(){return fname;}
    public static String getLastname(){return lastname;}
    public static String getEmail(String email){ ;return email;}

    public static void signUp() { }

    public static void signIn() { }

    public static String getEmail() {return email; }

    public String getPhone(){return phone;}

    //set methods to edit account
    public void setUsername(String newUsername){ newUsername= username;}
    public void setPassword(String newPassword){ newPassword=password;}
    public void setFirstname(String firstname){firstname= fname;}
    public void setLastname(String lastname){ this.lastname= lastname;}
    public void setEmail(String newEmail){newEmail= email;}


    public static void editAccount(String newUsername, String newPassword, String newEmail, String newPhone, String lname)
    {
        username=newUsername;
        password=newPassword;
        email=newEmail;
        phone=newPhone;
        lastname=lname;
    }
    //delete flight data
    public void deleteData(String fOrigin, String fDestination, String fDate,int numOfPassengers)
    {
        fOrigin=null;
        fDestination=null;
        fDate=null;
        numOfPassengers=0;


    }
    public void isSignIn()
    {

        System.out.println("Username:"+getUsername()+"Password: "+getPassword());


    }
    public void isSignUp()
    {

        System.out.println("First name:"+getFirstname()+" last name: "+getLastname()+"Email: "+getEmail()+"Phone number: "+getPhone());
        System.out.println(" account has been created successfully.");


    }

}

