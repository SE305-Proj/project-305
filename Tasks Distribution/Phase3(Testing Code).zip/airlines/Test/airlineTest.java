import org.junit.Test;

import static org.junit.Assert.*;

public class airlineTest {

    private String fOrigin;

    @Test
    public void editAccount() {
        airline.signUp(); // Sign up first to have initial data

        airline.editAccount("updatedUsername", "updatedPassword", "updatedEmail", "1234567890", "Doe");

        assertEquals("updatedUsername", airline.getUsername());
        assertEquals("updatedPassword", airline.getPassword());
        assertEquals("updatedEmail", airline.getEmail());
        assertEquals("Doe", airline.getLastname()); // Phone number is not edited (missing setter)
    }


    @Test
    public void deleteData() {
        airline airline = new airline();

        // Set up some initial flight data
        airline.fOrigin = "New York";
        String fDestination = "Los Angeles";
        String fDate = "2024-05-06";
        int numOfPassengers = 100;

        
        airline.deleteData(fOrigin, fDestination, fDate, numOfPassengers);
    }



    @Test
    public void isSignIn() {
        // Sign up first to create user credentials
        airline.signUp(); // Simulate sign-up with mocked input

        // Simulate successful sign-in with mocked user data
        airline.signIn();  // Mocked input not needed here (method doesn't take input)
    }


    @Test
    public void testSignUpSuccess() {
        Airline airline = new Airline();
        String username = "new_user";
        String password = "new_password";
        String email = "new@email.com";
        String firstname = "John";
        String lastname = "Doe";
        String phone = "1234567890";

        // Simulate successful sign up logic (modify based on implementation)
        boolean signUpResult = airline.signUp(username, password, email, firstname, lastname, phone);

    }

    private class Airline {
        public boolean signUp(String username, String password, String email, String firstname, String lastname, String phone){
            return false;
        }
    }
    }
