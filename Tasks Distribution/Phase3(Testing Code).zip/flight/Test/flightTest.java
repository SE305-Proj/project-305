import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class flightTest {

    @Test
    public void testSearchForFlights() {
        Flight flight = new Flight();

        // Capture console output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        flight.searchForFlights("London", "Paris", "2024-06-10", 1);

        // Restore console output
        System.setOut(System.out);


    }

    @Test
    public void testToString() {
        Flight flight = new Flight();

        String expectedString = "Flight{flightNumber='456', origin='Tokyo', destination='Los Angeles', departureTime='', arrivalTime=''}\n";

    }

    private class Flight {
        public Flight() { }

        public void searchForFlights(String london, String paris, String s, int i) { }
    }
}
