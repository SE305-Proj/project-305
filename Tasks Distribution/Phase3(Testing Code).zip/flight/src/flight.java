public class flight {
    // define private variables to collect the data.
    private String flightNumber=" ";
    private String flightOrigin="Bahrain";
    private String flightDestination=" ";
    private String flightDate=" ";
    private String departureTime;
    private String arrivalTime;
    private String passengerFirstName="";
    private String passengerLastName="";
    private int numOfPassengers=0;
    private double ticketPrice=0.0;
    private int confirmationNumber=0;

    // a public constructor
    public flight(int fNumber, String fOrigin, String fDestination, String fDate,String fName,
                  String lName, int nPassengers, double price,int confirmationNo) {
        fNumber = 1;
        fOrigin = flightOrigin;
        fDestination = flightDestination;
        fDate=flightDate;
        fName=passengerFirstName;
        lName=passengerLastName;
        nPassengers=1;
        price=ticketPrice;
        confirmationNo=confirmationNumber; }

    public String getFlightNumber(){return flightNumber;}
    public String getFlightOrigin(){return flightOrigin;}
    public String getFlightDestination(){return flightDestination;}
    public String getFlightDate(){return flightOrigin;}
    public String getDepartureTime(){return departureTime;}
    public String getArrivalTime(){return arrivalTime;}
    public String getPassengerFirstName(){return passengerFirstName;}
    public String getPassengerLastName(){return passengerLastName;}
    public int getNumOfPassengers(){return numOfPassengers;}
    public double getTicketPrice(){return ticketPrice;}
    public int getConfirmationNumber(){return confirmationNumber;}

    // get and set methods to get the values from user or set the value.
    public void setFlightNumber(String fNumber){fNumber=flightNumber;}
    public void setFlightOrigin(String fOrigin){fOrigin=flightOrigin;}
    public void setFlightDestination(String fDestination){fDestination=flightDestination;}
    public void setFlightDate(String fDate){fDate=flightDate;}
    public void setDepartureTime(String Dtime){departureTime=Dtime;}
    public void setArrivalTime(String Atime){arrivalTime=Atime;}
    public void setPassengerFirstName(String fName){fName=passengerFirstName;}
    public void setPassengerLastName(String lName){lName=passengerLastName;}
    public void setNumOfPassengers(int nPassengers){nPassengers=numOfPassengers;}
    public void setTicketPrice(double price){price=ticketPrice;}
    public void setConfirmationNumber(int confirmationNo){confirmationNo=confirmationNumber;}


    // method to search for a flight
    public void searchForFlights(String flightOrigin, String fDestination, String flightDate, int numOfPassengers) {
        System.out.println("Search for flights from " + flightOrigin +
                " to " + fDestination + " on " + flightDate + " for " + numOfPassengers + " passengers.");
    }
    //add flight to the system and keep it available for users.
    public String toString() {
        return "Flight{" +
                "flightNumber='" + flightNumber + '\'' +
                ", origin='" + flightOrigin + '\'' +
                ", destination='" + flightDestination + '\'' +
                ", departureTime='" + departureTime + '\'' +
                ", arrivalTime='" + arrivalTime + '\'' +
                '}';
    }
    public void removeFlight(String flightNumber)
    {
        // Find the flight with the given flight number and remove it from the system;


    }
    //update flight details.

    public void isUpdateFlight(String fNumber, String fOrigin, String fDestination, String fDate, double price)
    {

        fNumber = flightNumber;
        fOrigin = flightOrigin;
        fDestination = flightDestination;
        fDate=flightDate;
        price=ticketPrice;
        // return method to save the updated flight information.
        System.out.println(
                "Flight number: " + fNumber +
                        " flight origin: " + fOrigin +
                        " flight destination: " + fDestination+
                        "flight date"+fDate+
                        "ticket price"+price);
        System.out.println("changes are saved successfully");


    }


}



