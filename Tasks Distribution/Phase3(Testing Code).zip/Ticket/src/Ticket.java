public class Ticket {

    // buy ticket
// private variables.
    private boolean businessClass;
    private boolean FirstClass;
    private boolean EconClass;
    private double ticketPrice;
    private boolean child;
    private boolean adult;
    private boolean infant;
    private double numOfPassengers;
    private int age;
    private double totalPrice;
    private long cardNumber;
    private String cardHolderName;
    public int pinNumber;
    public boolean pay;
    public int OTP;
    public String referenceNumber;
    //get methods
    public double getTicketPrice() {return ticketPrice;}
    public double getTotalPrice() {return totalPrice;}
    public int getAge() {return age;}
    public int getOTP() {return OTP;}
    public String getReferenceNumber(){return referenceNumber;}

    public long getCardNumber() {return cardNumber;}
    public String getCardHolderName() {return cardHolderName;}
    public int getPinNumber() {return pinNumber;}
    //set methods
    public void setAge(int age) {this.age = age;}
    public void setCardNumber(long l) {double cardNumber;}
    public void setCardHolderName(String l) {double cardHolderName;}
    public void setBusinessClass(boolean b){}
    public void setOTP(int otp) { this.OTP = otp; }
    public void setPinNumber(int pinNumber) { this.pinNumber = pinNumber; }
    public void setTotalPrice(double totalPrice) {this.totalPrice = totalPrice;}
    public void setTicketPrice(double ticketPrice) {this.ticketPrice = ticketPrice;}
    public void setReferenceNumber(String referenceNumber) { this.referenceNumber = referenceNumber; }

    public void buyTicket()
    {
        if (age>10)
            adult=true;

        if (age<2)
            infant=true;

        if(age>2 && age<10)
            child=true;


        if(businessClass)
        {
            if(infant){
                ticketPrice=150;
                numOfPassengers++;}
            if (child){
                ticketPrice=300;
                numOfPassengers++;}
            if(adult){
                ticketPrice=500;
                numOfPassengers++;}
            totalPrice=ticketPrice*numOfPassengers;
        }
        if(FirstClass)
        {
            if (infant){
                ticketPrice = 200;}
            numOfPassengers++;
            if (child){
                ticketPrice = 500.0;
                numOfPassengers++;}
            if (adult){
                ticketPrice = 700.0;
                numOfPassengers++;}
            totalPrice=ticketPrice*numOfPassengers;
        }
        if(EconClass)
        {
            if (infant) {
                ticketPrice = 100.0;
                numOfPassengers++;}
            else if (child){
                ticketPrice = 150.0;}
            numOfPassengers++;
            if(adult){
                ticketPrice = 250.0;
                numOfPassengers++;}
            totalPrice=ticketPrice*numOfPassengers;
        }
        System.out.println("Total price: "+totalPrice);
    }// end of buy ticket method.
    // method to enter payment details.
    public void makePayment(boolean visaCard, boolean masterCard)
    {
        if (visaCard||masterCard)
        {
            System.out.println("Enter the card number: "+getCardNumber());
            System.out.println("Enter the card Holder Name: "+getCardNumber());
            System.out.println("Enter the card pin: "+getPinNumber());
        }

    }
    // method to complete payment process
    public boolean isPay()
    {
        if(pay)
            System.out.println("Please enter the OTP received from SMS or E-mail to complete payment process: "+getOTP());
        return true;
    }
    // method to cancel ticket.
    public boolean isCancel()
    {
        System.out.println("Please enter the flight reference Number: "+getReferenceNumber());
        return true;
    }
    // method to confirm ticket.
    public boolean IsConfirmed()
    {
        System.out.println("Please enter the OTP received from SMS or E-mail to confirm reservation: "+getOTP());
        return true;
    }


}
