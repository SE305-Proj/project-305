import org.junit.Test;

import static org.junit.Assert.*;

public class TicketTest {

    @Test
    public void buyTicket() {
        Ticket ticket = new Ticket();
        ticket.setAge(-1); // Negative age should throw exception
        ticket.setBusinessClass(true);

    }

    @Test
    public void makePayment() {
        Ticket ticket = new Ticket();
        ticket.setCardNumber(1234567890L);
        ticket.setCardHolderName("Fatima ");
        ticket.setPinNumber(1234);
        ticket.makePayment(true, true);  // Simulate both visa and mastercard
        // We cannot directly test console output,

    }

    @Test
    public void isCancel() {
        Ticket ticket = new Ticket();
        ticket.setReferenceNumber("ABC123");
        boolean cancelled = ticket.isCancel();
        // We cannot directly test console output,
        // but verify the return value (always true)
        assertTrue(cancelled);
    }

    @Test
    public void isConfirmed() {
        Ticket ticket = new Ticket();
        ticket.setOTP(123456);
        boolean confirmed = ticket.IsConfirmed();
        // We cannot directly test console output,
        // but verify the return value (always true)
        assertTrue(confirmed);
    }
}